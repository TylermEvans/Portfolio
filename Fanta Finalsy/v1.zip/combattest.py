import pygame
import enemy
import playerclass
import random
import time
#name1=input("Name of your Mounty:")
#name2=input("Name of your Ranger:")
#name3=input("Name of your Magician:")
#name4=input("Name of the useless bard:")
p1=playerclass.mounty()
p1.modify()
p2=playerclass.ranger()
p2.modify()
p3=playerclass.magician()
p3.modify()
p4=playerclass.bard()
p4.modify()
pygame.init()
screen=pygame.display.set_mode((800,600),pygame.SWSURFACE,24)
game=True
p1pos=[100,100]
p2pos=[100,100]
p3pos=[100,100]
p4pos=[100,100]
pressing=False
freq=0
steps=0
def fontwrite(x,y,string,color=(0,0,0)):
    font_Pygame=pygame.font.SysFont("Arial",24)
    screen.blit(font_Pygame.render(string,True,color),(x,y))
class fight(object):
    def __init__(self):
        self.fighting=False
        self.wonfight=False
        self.losefight=False
    def encounter(self,chance,frequency):
        if chance<100:
            fightnum=random.randint(chance,1000)
        else:
            fightnum=1000
        if fightnum>frequency:
            self.fighting=True
    def initencounter(self,p1,p2,p3,p4,minsize,maxsize):
        
        self.enemylist=[]
        self.playerlist=[]
        enemyencounter=random.randint(minsize,maxsize)
        self.enemyencountersize=enemyencounter
        while enemyencounter>0:
            enemysize=random.randint(1,2)
            if enemyencounter==1:
                enemysize=1
            if enemysize==1:
                self.enemylist.append(enemy.fistsnake())
            if enemysize==2:
                self.enemylist.append(enemy.snakefist())
            enemyencounter-=enemysize
            enemysize=0
        
        self.encountersize=len(self.enemylist)
        self.playerturn=True
        self.enemyturn=False
        self.playerlist.append(p1)
        self.playerlist.append(p2)
        self.playerlist.append(p3)
        self.playerlist.append(p4)
        self.party=len(self.playerlist)
    def playerattack(self):
        for chara in self.playerlist:
            if chara.alive==False:
                continue
            if self.encountersize<=0:
                continue
            target=random.randint(0,len(self.enemylist)-1)
            i=self.enemylist[target]
            while i.alive==False and self.encountersize>0:
                if self.encountersize<=0:
                    continue
                target=random.randint(0,len(self.enemylist)-1)
                i=self.enemylist[target]
            i.hp-=chara.damage
            screen.fill((255,255,255))
            fontwrite(20,500,str(i.enemyname)+" has taken "+str(chara.damage)+" damage!")
            self.update(True)
            if i.hp<=0:
                i.alive=False
                self.encountersize-=1
                screen.fill((255,255,255))
                fontwrite(20,500,str(i.enemyname)+" has perished!")
                self.update(True)
            if self.wonfight==True or self.losefight==True:
                continue
        if self.encountersize>0:
            self.playerturn=False
            self.enemyturn=True
        else:
            self.wonfight=True
    def enemyattack(self):
        for e in self.enemylist:
            if e.alive==False:
                continue
            target2=random.randint(0,len(self.playerlist)-1)
            i=self.playerlist[target2]
            while i.alive==False:
                if self.party<=0:
                    continue
                target2=random.randint(0,len(self.playerlist)-1)
                i=self.playerlist[target2]
            i.hp-=e.damage
            screen.fill((255,255,255))
            fontwrite(20,500,str(i.char)+" has taken "+str(e.damage)+" damage!")
            self.update(True)
            if i.hp<=0:
                i.alive=False
                screen.fill((255,255,255))
                fontwrite(20,500,str(i.char)+" has become rip in peace-d!")
                self.update(True)
                self.party-=1
                
            if self.party<=0:
                break
        if self.party>0:
            self.enemyturn=False
            self.playerturn=True
        else:
            self.losefight=True
    def update(self,w):
        pygame.draw.rect(screen,(0,0,0),(0,450,799,150),3)
        pygame.draw.rect(screen,(0,0,0),(0,0,799,125),2)
        fontwrite(10,10,"Mounty")
        fontwrite(10,40,"HP: "+str(self.playerlist[0].hp)+"/"+str(self.playerlist[0].maxhp))
        fontwrite(10,70,"MP: "+str(self.playerlist[0].mp)+"/"+str(self.playerlist[0].maxmp))
        fontwrite(210,10,"Ranger")
        fontwrite(210,40,"HP: "+str(self.playerlist[1].hp)+"/"+str(self.playerlist[1].maxhp))
        fontwrite(210,70,"MP: "+str(self.playerlist[1].mp)+"/"+str(self.playerlist[1].maxmp))
        fontwrite(410,10,"Magician")
        fontwrite(410,40,"HP: "+str(self.playerlist[2].hp)+"/"+str(self.playerlist[2].maxhp))
        fontwrite(410,70,"MP: "+str(self.playerlist[2].mp)+"/"+str(self.playerlist[2].maxmp))
        fontwrite(610,10,"Useless Bard")
        fontwrite(610,40,"HP: "+str(self.playerlist[3].hp)+"/"+str(self.playerlist[3].maxhp))
        fontwrite(610,70,"MP: "+str(self.playerlist[3].mp)+"/"+str(self.playerlist[3].maxmp))
        q=800/(self.enemyencountersize)
        p=q
        b=0
        for i in self.enemylist:
            if i.alive==True:
                i.render(screen,(q*(1+b),425-i.size*64))
            b+=1

        if w==False:
            fontwrite(20,500,"PRESS E TO FIGHT!")
        pygame.display.flip()
        if w==True:
            time.sleep(1)
    def winfight(self):
        for i in self.playerlist:
            if i.alive==True:
                for j in self.enemylist:
                    i.xp+=j.xp
            lv=i.level
            i.leveling()
            screen.fill((255,255,255))
            if i.level>lv:
                fontwrite(20,500,str(i.char)+" leveled up! Now they suck less!")
                self.update(True)
            screen.fill((255,255,255))
            if i.alive==True:
                fontwrite(20,500,str(i.char)+" has become level "+str(i.level))
                self.update(True)
                        
fight1=fight()
while game==True:
    screen.fill((0,0,0))
    pygame.event.pump()
    press=pygame.key.get_pressed()
    
    if pressing==True and press[pygame.K_w]==False and press[pygame.K_a]==False and press[pygame.K_s]==False and press[pygame.K_d]==False:
        pressing=False
        fight1.encounter(steps,freq)
    if pressing==False:
        if press[pygame.K_w]:
            pressing=True
            p4pos[1]=p3pos[1]
            p3pos[1]=p2pos[1]
            p2pos[1]=p1pos[1]
            p4pos[0]=p3pos[0]
            p3pos[0]=p2pos[0]
            p2pos[0]=p1pos[0]
            p1pos[1]-=50
            steps+=2
        if press[pygame.K_s]:
            pressing=True
            p4pos[1]=p3pos[1]
            p3pos[1]=p2pos[1]
            p2pos[1]=p1pos[1]
            p4pos[0]=p3pos[0]
            p3pos[0]=p2pos[0]
            p2pos[0]=p1pos[0]
            p1pos[1]+=50
            steps+=2
        if press[pygame.K_a]:
            pressing=True
            p4pos[0]=p3pos[0]
            p3pos[0]=p2pos[0]
            p2pos[0]=p1pos[0]
            p4pos[1]=p3pos[1]
            p3pos[1]=p2pos[1]
            p2pos[1]=p1pos[1]
            p1pos[0]-=50
            steps+=2
        if press[pygame.K_d]:
            pressing=True
            p4pos[0]=p3pos[0]
            p3pos[0]=p2pos[0]
            p2pos[0]=p1pos[0]
            p4pos[1]=p3pos[1]
            p3pos[1]=p2pos[1]
            p2pos[1]=p1pos[1]
            p1pos[0]+=50
            steps+=2
    freq=970
    
    pygame.draw.circle(screen,(255,255,255),(p4pos[0],p4pos[1]),20)
    pygame.draw.circle(screen,(0,0,255),(p3pos[0],p3pos[1]),20)
    pygame.draw.circle(screen,(0,255,0),(p2pos[0],p2pos[1]),20)
    pygame.draw.circle(screen,(255,0,0),(p1pos[0],p1pos[1]),20)
    pygame.display.flip()
    if fight1.fighting==True:
        screen.fill((255,255,255))
        pygame.display.flip()
        fight1.initencounter(p1,p2,p3,p4,4,6)
        enemystr="ENEMY ENCOUNTER\n"+str(fight1.encountersize)+"\n"
        for i in range(len(fight1.enemylist)):
            i=fight1.enemylist[i]
            i.modify()
            enemystr+=i.enemyname+" "
    while fight1.fighting==True:
        pygame.event.pump()
        press=pygame.key.get_pressed()
        screen.fill((255,255,255))
        if pressing==True and press[pygame.K_e]==False:
            pressing=False
        if pressing==False:
            if press[pygame.K_e]:
                pressing=True
                if fight1.enemyturn==True:
                    fight1.enemyattack()
                if fight1.playerturn==True:
                    fight1.playerattack()
        if fight1.encountersize<=0:
            fight1.wonfight=True
        if fight1.party<=0:
            fight1.losefight==True
        if fight1.wonfight==True:
            fight1.winfight()
            fight1.wonfight=False
            fight1.fighting=False
            steps=0
        if fight1.losefight==True:
            game=False
            fight1.fighting=False
        fight1.update(False)
pygame.display.quit()

    
    
