class player(object):
    def __init__(self):
        self.level=1
        self.xp=0
        self.nextlevel=50
        self.oldlevel=50
        self.maxhp=100
        self.hp=self.maxhp
        self.hplevelup=10
        self.maxmp=50
        self.mp=self.maxmp
        self.mplevelup=5
        self.damage=10
        self.damagelevelup=2
        self.skillset=[]
        self.alive=True
    def leveling(self):
        if self.xp>=self.nextlevel:
            self.oldlevel=self.nextlevel
            self.nextlevel=self.oldlevel+50*(self.level-1)
            self.level+=1
            self.maxhp+=self.hplevelup
            self.maxmp+=self.mplevelup
            self.damage+=self.damagelevelup
class mounty(player):
    def modify(self):
        self.maxhp+=50
        self.maxmp-=20
        self.hplevelup+=5
        self.damage+=5
        self.mplevelup-=2
        self.damagelevelup-=1
        self.hp=self.maxhp
        self.mp=self.maxmp
        self.char="Mounty"
class bard(player):
    def modify(self):
        self.maxhp-=90
        self.maxmp-=45
        self.hplevelup-=9
        self.damage-=9
        self.mplevelup-=4
        self.damagelevelup+=5
        self.hp=self.maxhp
        self.mp=self.maxmp
        self.char="Useless Bard"
class ranger(player):
    def modify(self):
        self.maxmp-=10
        self.hplevelup+=2
        self.damage+=2
        self.mplevelup-=1
        self.damagelevelup
        self.hp=self.maxhp
        self.mp=self.maxmp
        self.char="Ranger"
class magician(player):
    def modify(self):
        self.maxhp-=50
        self.maxmp+=40
        self.hplevelup-=5
        self.damage-=5
        self.mplevelup+=5
        self.damagelevelup-=1
        self.hp=self.maxhp
        self.mp=self.maxmp
        self.char="Magican"
while __name__=="__main__":
    dank=True
    player1=bard()
    player1.modify()
    while dank==True:
        print(player1.level)
        print(player1.xp)
        print(player1.maxhp)
        print(player1.maxmp)
        player1.xp+=50
        print(player1.xp)
        player1.leveling()
        print(player1.level)
        print(player1.maxhp)
        print(player1.maxmp)
        dank=False
    break

    
