import pygame
class enemy(object):
    def __init__(self):
        self.hp=0
        self.mp=0
        self.damage=0
        self.size=0
        self.skills=[]
        self.image=None
        self.alive=True
    def render(self,screen,position):
        self.image=pygame.image.load(self.imagename)
        ix=self.image.get_width()
        iy=self.image.get_height()
        self.image=pygame.transform.scale(self.image,(int(ix*(self.size*.8)),int(iy*self.size*.9)))
        screen.blit(self.image,position)
class fistsnake(enemy):
    def modify(self):
        self.hp+=25
        self.damage+=5
        self.size+=2
        self.enemyname="FISTSNAKE"
        self.xp=20
        self.imagename="fist snake.png"
class snakefist(enemy):
    def modify(self):
        self.hp+=100
        self.damage+=10
        self.size+=4
        self.enemyname="SNAKEFIST"
        self.imagename="snakefists.png"
        self.xp=50
